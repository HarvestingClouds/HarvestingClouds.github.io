# plentychess emscripten-single-thread corresponding source

This archive contains the upstream source snapshot, local browser integration scripts/adapters, docs, and required network/model asset provenance for the generated plentychess browser artifacts.

## Rebuild

Install Node, Emscripten, a native C++ compiler, make, curl and git (no npm dependencies are needed for the engine build), then run:

```sh
mkdir -p "$PWD/.build" "$PWD/out/public/plentychess"
for tier in base sse41 relaxed; do
  build="$PWD/.build/plentychess-$tier"
  rm -rf "$build"
  cp -a "$PWD/upstream/plentychess-50ad9f1b523063cbbbf599fe0547f42870fe2906" "$build"
  suffix=""; sse41=0; relaxed=0
  case "$tier" in
    sse41) suffix="-sse41"; sse41=1 ;;
    relaxed) suffix="-relaxed-simd128"; relaxed=1 ;;
  esac
  PLENTYCHESS_SKIP_GIT=1 PLENTYCHESS_BUILD_DIR="$build" PLENTYCHESS_NET_DIR="$PWD/assets" PLENTYCHESS_WASM_SSE41="$sse41" PLENTYCHESS_WASM_RELAXED_SIMD="$relaxed" PLENTYCHESS_EMSCRIPTEN_JS_OUT="$PWD/out/public/plentychess/plentychess-emscripten$suffix.js" node scripts/build_plentychess_emscripten.mjs || exit 1
done
```

The build script applies patches/plentychess-emscripten.patch to the upstream snapshot in upstream/plentychess-50ad9f1b523063cbbbf599fe0547f42870fe2906/.

The build writes outputs under `out/public/plentychess/` or the upstream build directory as noted by the command above.

See `ASSET_PROVENANCE.json` for network/model source URLs and hashes.
