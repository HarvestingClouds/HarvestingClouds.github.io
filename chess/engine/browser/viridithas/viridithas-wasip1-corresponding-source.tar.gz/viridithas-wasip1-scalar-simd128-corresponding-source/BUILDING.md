# viridithas wasip1-scalar-simd128 corresponding source

This archive contains the upstream source snapshot, local browser integration scripts/adapters, docs, and required network/model asset provenance for the generated viridithas browser artifacts.

## Rebuild

Install Node dependencies and the documented upstream toolchain, then run:

```sh
npm ci
VIRIDITHAS_SKIP_GIT=1 VIRIDITHAS_BUILD_DIR="$PWD/upstream/viridithas-0631113e2215714c54d397cce9a8caebc5e6f8ee" VIRIDITHAS_NET_DIR="$PWD/assets" VIRIDITHAS_WASM_OUT="$PWD/out/public/viridithas/viridithas.wasm" npm run viridithas:build-wasi && VIRIDITHAS_SKIP_GIT=1 VIRIDITHAS_BUILD_DIR="$PWD/upstream/viridithas-0631113e2215714c54d397cce9a8caebc5e6f8ee" VIRIDITHAS_NET_DIR="$PWD/assets" VIRIDITHAS_WASM_SIMD=1 VIRIDITHAS_WASM_OUT="$PWD/out/public/viridithas/viridithas-simd128.wasm" npm run viridithas:build-wasi && VIRIDITHAS_SKIP_GIT=1 VIRIDITHAS_BUILD_DIR="$PWD/upstream/viridithas-0631113e2215714c54d397cce9a8caebc5e6f8ee" VIRIDITHAS_NET_DIR="$PWD/assets" VIRIDITHAS_WASM_RELAXED_SIMD=1 VIRIDITHAS_WASM_OUT="$PWD/out/public/viridithas/viridithas-relaxed-simd128.wasm" npm run viridithas:build-wasi
```

The build script applies patches/viridithas-wasip1.patch to the upstream snapshot in upstream/viridithas-0631113e2215714c54d397cce9a8caebc5e6f8ee/.

The build writes outputs under `out/public/viridithas/` or the upstream build directory as noted by the command above.

See `ASSET_PROVENANCE.json` for network/model source URLs and hashes.
