import { resolvePublicAssetUrl } from './assetUrls.ts';
import { supportsWasmRelaxedSimd, supportsWasmSimd } from './recklessVariants.ts';

export const DEFAULT_VIRIDITHAS_WASM_URL = resolvePublicAssetUrl('/viridithas/viridithas.wasm');

export type ViridithasAssetStatus = 'unknown' | 'checking' | 'ok' | 'missing';

export interface ViridithasVariant {
  key: 'default' | 'simd' | 'relaxed-simd' | 'custom';
  label: string;
  wasmUrl: string;
  note: string;
  assetStatus?: ViridithasAssetStatus;
  /** Lab URL overrides are same-origin but not in the deployed path set. */
  allowUnshippedProbe?: boolean;
}

export const VIRIDITHAS_DEFAULT_VARIANT: ViridithasVariant = {
  key: 'default',
  label: 'Viridithas',
  wasmUrl: DEFAULT_VIRIDITHAS_WASM_URL,
  note: 'Experimental patched Viridithas wasm32-wasip1 scalar build with one-shot, persistent, and batch benchmark modes.',
};

export const VIRIDITHAS_SIMD_VARIANT: ViridithasVariant = {
  key: 'simd',
  label: 'Viridithas SIMD',
  wasmUrl: resolvePublicAssetUrl('/viridithas/viridithas-simd128.wasm'),
  note: 'Patched Viridithas wasm32-wasip1 build with wasm simd128 NNUE kernels. Default when the browser validates wasm SIMD but not Relaxed SIMD. v20.0.0 tag: 40/40 fixed-depth parity with scalar; browser persistent startpos movetime 1000ms median about 458k NPS versus 68k scalar.',
};

export const VIRIDITHAS_RELAXED_SIMD_VARIANT: ViridithasVariant = {
  key: 'relaxed-simd',
  label: 'Viridithas Relaxed SIMD',
  wasmUrl: resolvePublicAssetUrl('/viridithas/viridithas-relaxed-simd128.wasm'),
  note: 'Viridithas build using the relaxed integer dot for the L1 NNUE kernels (exact: QA=255/FT_SHIFT=9 keep activations in 0..127). Default when the browser validates Relaxed SIMD. v20.0.0 tag: 40/40 fixed-depth parity; browser persistent startpos movetime 1000ms median about 532k NPS, +16% over simd128.',
};

const assetChecks = new Map<string, Promise<ViridithasAssetStatus>>();

const DEPLOYED_VIRIDITHAS_PATHS = new Set([
  '/viridithas/viridithas.wasm',
  '/viridithas/viridithas-simd128.wasm',
  '/viridithas/viridithas-relaxed-simd128.wasm',
]);

function isLocalDevelopmentOrigin(): boolean {
  if (typeof location === 'undefined') return true;
  return location.hostname === 'localhost' || location.hostname === '127.0.0.1' || location.hostname === '::1' || location.hostname === '[::1]';
}

function assetPathname(raw: string): string {
  try {
    const base = typeof location !== 'undefined' ? location.href : 'http://localhost/';
    return new URL(raw, base).pathname;
  } catch {
    return raw;
  }
}

function shouldSkipKnownUnshippedProbe(variant: ViridithasVariant): boolean {
  if (variant.key === 'custom' || variant.allowUnshippedProbe || isLocalDevelopmentOrigin()) return false;
  const pathname = assetPathname(variant.wasmUrl);
  return pathname.startsWith('/viridithas/') && !DEPLOYED_VIRIDITHAS_PATHS.has(pathname);
}

// Promotion order: relaxed integer dot > simd128 > scalar. All variants are
// value-exact (40/40 fixed-depth parity), so this is a speed ladder gated by
// WebAssembly feature validation.
export function defaultViridithasVariantKey(): ViridithasVariant['key'] {
  if (supportsWasmRelaxedSimd()) return 'relaxed-simd';
  return supportsWasmSimd() ? 'simd' : 'default';
}

/**
 * Resolve the feature-detected default against deployed assets: a missing
 * relaxed artifact falls back to simd128, and a missing simd128 artifact
 * falls back to scalar. Explicit user selections are honored as-is.
 */
export async function resolveDefaultViridithasVariantAssetFallback(
  variant: ViridithasVariant,
  explicit: boolean,
  onChange?: () => void,
): Promise<ViridithasVariant> {
  if (explicit || variant.key === 'default' || variant.key === 'custom') return variant;
  const status = await checkViridithasVariantAsset(variant, onChange);
  if (status !== 'missing') return variant;
  if (variant.key === 'relaxed-simd' && supportsWasmSimd()) {
    return resolveDefaultViridithasVariantAssetFallback(VIRIDITHAS_SIMD_VARIANT, false, onChange);
  }
  return VIRIDITHAS_DEFAULT_VARIANT;
}

export const VIRIDITHAS_VARIANTS: readonly ViridithasVariant[] = [VIRIDITHAS_SIMD_VARIANT, VIRIDITHAS_RELAXED_SIMD_VARIANT, VIRIDITHAS_DEFAULT_VARIANT];

function sameOriginViridithasAsset(raw: string | null | undefined): string | undefined {
  if (!raw) return undefined;
  try {
    const base = typeof location !== 'undefined' ? location.origin : 'http://localhost';
    const url = new URL(raw, base);
    if (url.origin !== base || !url.pathname.startsWith('/viridithas/')) return undefined;
    return `${url.pathname}${url.search}`;
  } catch {
    return undefined;
  }
}

export function normalizeViridithasVariant(raw: string | null | undefined): ViridithasVariant['key'] {
  const value = String(raw ?? '')
    .toLowerCase()
    .replace(/[ _-]+/g, '');
  if (value === 'relaxedsimd' || value === 'relaxed' || value === 'relaxedsimd128') return 'relaxed-simd';
  if (value === 'simd' || value === 'simd128' || value === 'wasmsimd') return 'simd';
  if (value === 'scalar' || value === 'default') return 'default';
  if (value === 'custom') return 'custom';
  return 'default';
}

export function viridithasVariantByKey(key: string): ViridithasVariant {
  const normalized = normalizeViridithasVariant(key);
  if (normalized === 'relaxed-simd')
    return supportsWasmRelaxedSimd() ? VIRIDITHAS_RELAXED_SIMD_VARIANT : supportsWasmSimd() ? VIRIDITHAS_SIMD_VARIANT : VIRIDITHAS_DEFAULT_VARIANT;
  return VIRIDITHAS_VARIANTS.find((variant) => variant.key === normalized) ?? VIRIDITHAS_DEFAULT_VARIANT;
}

export function hasExplicitViridithasVariant(params: URLSearchParams): boolean {
  return params.has('viridithasWasm') || params.has('viridithas') || params.has('viridithasVariant');
}

export function viridithasVariantFromParams(params: URLSearchParams): ViridithasVariant {
  const customUrl = sameOriginViridithasAsset(params.get('viridithasWasm'));
  if (customUrl)
    return { key: 'custom', label: 'Viridithas Custom', wasmUrl: customUrl, note: 'Custom same-origin Viridithas WASM URL from ?viridithasWasm=…' };
  return viridithasVariantByKey(params.get('viridithas') ?? params.get('viridithasVariant') ?? defaultViridithasVariantKey());
}

export function viridithasVariantAssetStatus(variant: ViridithasVariant): ViridithasAssetStatus {
  return variant.assetStatus ?? 'unknown';
}

export function checkViridithasVariantAsset(variant: ViridithasVariant, onChange?: () => void): Promise<ViridithasAssetStatus> {
  if (variant.assetStatus === 'ok' || variant.assetStatus === 'missing') return Promise.resolve(variant.assetStatus);
  const existing = assetChecks.get(variant.wasmUrl);
  if (existing) {
    variant.assetStatus = 'checking';
    return existing.then((status) => {
      variant.assetStatus = status;
      onChange?.();
      return status;
    });
  }
  if (shouldSkipKnownUnshippedProbe(variant)) {
    variant.assetStatus = 'missing';
    onChange?.();
    return Promise.resolve(variant.assetStatus);
  }
  variant.assetStatus = 'checking';
  const promise = fetch(variant.wasmUrl, { method: 'HEAD' })
    .then((response) => (response.ok ? 'ok' : ('missing' as ViridithasAssetStatus)))
    .catch(() => 'missing' as ViridithasAssetStatus)
    .then((status) => {
      variant.assetStatus = status;
      assetChecks.delete(variant.wasmUrl);
      onChange?.();
      return status;
    });
  assetChecks.set(variant.wasmUrl, promise);
  onChange?.();
  return promise;
}
