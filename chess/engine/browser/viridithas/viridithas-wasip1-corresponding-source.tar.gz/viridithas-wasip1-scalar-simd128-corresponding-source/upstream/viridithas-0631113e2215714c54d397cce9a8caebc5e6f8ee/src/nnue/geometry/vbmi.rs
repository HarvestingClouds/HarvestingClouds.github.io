#![expect(
    clippy::undocumented_unsafe_blocks,
    clippy::cast_ptr_alignment,
    clippy::cast_possible_wrap
)]

use std::arch::x86_64::{
    __m128i, __m512i, _mm_loadu_si128, _mm512_broadcast_i32x4, _mm512_loadu_si512,
    _mm512_mask_blend_epi8, _mm512_maskz_shuffle_epi8, _mm512_permutexvar_epi8, _mm512_set1_epi8,
    _mm512_shuffle_i64x2, _mm512_test_epi8_mask, _mm512_testn_epi8_mask,
};

use crate::{
    chess::{piece::Piece, types::Square},
    nnue::geometry::Bit,
};

use super::{BitRays, INCOMING_SLIDERS_MASK, INCOMING_THREATS_MASK, PERMUTATION, PIECE_TO_BIT};

#[derive(Clone, Copy)]
#[repr(transparent)]
pub struct Vector {
    pub raw: __m512i,
}

impl Vector {
    pub fn flip(self) -> Self {
        unsafe {
            Self {
                raw: _mm512_shuffle_i64x2(self.raw, self.raw, 0b01_00_11_10),
            }
        }
    }
}

pub struct Permutation {
    pub indexes: Vector,
    pub valid: u64,
}

pub fn permutation_for(focus: Square) -> Permutation {
    unsafe {
        let indexes = _mm512_loadu_si512(PERMUTATION[focus.index()].as_ptr().cast());
        let valid = _mm512_testn_epi8_mask(indexes, _mm512_set1_epi8(0x80u8 as i8));
        Permutation {
            indexes: Vector { raw: indexes },
            valid,
        }
    }
}

pub fn permute_mailbox(
    permutation: &Permutation,
    mailbox: &[Option<Piece>; 64],
) -> (Vector, Vector) {
    unsafe {
        let lut = _mm512_broadcast_i32x4(_mm_loadu_si128(PIECE_TO_BIT.as_ptr().cast::<__m128i>()));

        let masked_mailbox = _mm512_loadu_si512(mailbox.as_ptr().cast());
        let permuted = _mm512_permutexvar_epi8(permutation.indexes.raw, masked_mailbox);
        let bits = _mm512_maskz_shuffle_epi8(permutation.valid, lut, permuted);
        (Vector { raw: permuted }, Vector { raw: bits })
    }
}

pub fn permute_mailbox_ignoring(
    permutation: &Permutation,
    mailbox: &[Option<Piece>; 64],
    ignore: Square,
) -> (Vector, Vector) {
    const NO_PIECE: i8 = unsafe { std::mem::transmute::<Option<Piece>, i8>(None) };
    unsafe {
        let lut = _mm512_broadcast_i32x4(_mm_loadu_si128(PIECE_TO_BIT.as_ptr().cast::<__m128i>()));

        let ignore_mask: u64 = 1 << ignore.inner();
        let masked_mailbox = _mm512_mask_blend_epi8(
            ignore_mask,
            _mm512_loadu_si512(mailbox.as_ptr().cast()),
            _mm512_set1_epi8(NO_PIECE),
        );
        let permuted = _mm512_permutexvar_epi8(permutation.indexes.raw, masked_mailbox);
        let bits = _mm512_maskz_shuffle_epi8(permutation.valid, lut, permuted);
        (Vector { raw: permuted }, Vector { raw: bits })
    }
}

pub fn closest_occupied(bits: Vector) -> BitRays {
    unsafe {
        let occupied = _mm512_test_epi8_mask(bits.raw, bits.raw);
        let o = occupied | 0x8181_8181_8181_8181;
        BitRays((o ^ o.wrapping_sub(0x0303_0303_0303_0303)) & occupied)
    }
}

pub fn incoming_attackers(bits: Vector, closest: BitRays) -> BitRays {
    unsafe {
        let mask = _mm512_loadu_si512(INCOMING_THREATS_MASK.as_ptr().cast());
        BitRays(_mm512_test_epi8_mask(bits.raw, mask)) & closest
    }
}

pub fn incoming_sliders(bits: Vector, closest: BitRays) -> BitRays {
    unsafe {
        let mask = _mm512_loadu_si512(INCOMING_SLIDERS_MASK.as_ptr().cast());
        BitRays(_mm512_test_epi8_mask(bits.raw, mask)) & closest & BitRays::NON_KNIGHT
    }
}

pub fn test_bit(bits: Vector, bit: Bit) -> BitRays {
    unsafe {
        BitRays(_mm512_test_epi8_mask(
            bits.raw,
            _mm512_set1_epi8(bit.0 as i8),
        ))
    }
}
