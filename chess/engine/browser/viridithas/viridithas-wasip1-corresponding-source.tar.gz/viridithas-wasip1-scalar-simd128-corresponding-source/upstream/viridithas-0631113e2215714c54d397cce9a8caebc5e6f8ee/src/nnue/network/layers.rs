const AVX512CHUNK: usize = 512 / 32;

/// This constant determines the shift applied as part of the optimised
/// CReLU-into-pairwise inference. This could be 10 if we were exclusively
/// targeting x86 SIMD, but we wish to support NEON, which lacks an instruction
/// for performing u8×N to i8×N accumulating multiply-add into i32×N. Instead
/// we only have i8×N to i8×N into i32×N multiply via `vdotq_s32`, so we need to
/// keep our left-hand values in 0..127. Shifting by 16 - 9 achieves this.
const FT_SHIFT: u32 = 9;

#[allow(clippy::cast_precision_loss)]
const L1_MUL: f32 = (1 << FT_SHIFT) as f32 / (QA as i32 * QA as i32 * QB as i32) as f32;

const SWISH_K: f32 = 6.0;

#[cfg(feature = "nnz-counts")]
pub static NNZ_COUNT: std::sync::atomic::AtomicUsize = std::sync::atomic::AtomicUsize::new(0);
#[cfg(feature = "nnz-counts")]
pub static NNZ_DENOM: std::sync::atomic::AtomicUsize = std::sync::atomic::AtomicUsize::new(0);

#[cfg(feature = "ft-record")]
pub static FT_OUTPUT_FILE: std::sync::LazyLock<
    std::sync::Mutex<std::io::BufWriter<std::fs::File>>,
> = std::sync::LazyLock::new(|| {
    let f = std::fs::File::create("embeddings.bin").unwrap();
    let w = std::io::BufWriter::new(f);
    std::sync::Mutex::new(w)
});

mod simd {
    use crate::nnue::{
        network::{
            Align, L1_CHUNK_PER_32, L1_SIZE, L2_SIZE, L3_SIZE, QA,
            layers::{AVX512CHUNK, FT_SHIFT, L1_MUL, SWISH_K},
        },
        simd::{self, F32_CHUNK, I16_CHUNK, S, U8_CHUNK, VecI32},
    };
    use std::mem::MaybeUninit;

    #[cfg(feature = "nnz-counts")]
    use crate::nnue::network::layers::{NNZ_COUNT, NNZ_DENOM};
    #[cfg(feature = "nnz-counts")]
    use std::sync::atomic::Ordering;

    #[derive(Debug, Clone, Copy)]
    #[repr(C, align(16))]
    struct NNZEntry {
        indices: [u16; 8],
    }

    struct NNZTable {
        table: [NNZEntry; 256],
    }

    #[allow(clippy::cast_possible_truncation, clippy::cast_precision_loss)]
    const NNZ_TABLE: NNZTable = {
        let mut table = [NNZEntry { indices: [0; 8] }; 256];

        let mut i = 0;
        while i < 256 {
            let mut j = i;
            let mut k = 0;
            while j != 0 {
                table[i].indices[k] = j.trailing_zeros() as u16;
                j &= j - 1;
                k += 1;
            }
            i += 1;
        }

        NNZTable { table }
    };

    // used in only one place, separate function for clarity.
    unsafe fn reinterpret_as_i32s(
        ptr: &Align<[MaybeUninit<u8>; L1_SIZE]>,
    ) -> &Align<[i32; L1_SIZE / 4]> {
        let ptr = std::ptr::from_ref(ptr);
        // check that the reference is aligned:
        debug_assert!(ptr.cast::<i32>().is_aligned());
        debug_assert!(ptr.cast::<Align<[i32; L1_SIZE / 4]>>().is_aligned());
        // cast:
        // Safety: pointer is known to be aligned.
        unsafe { &*ptr.cast::<Align<[i32; L1_SIZE / 4]>>() }
    }

    #[allow(
        clippy::too_many_lines,
        clippy::identity_op,
        clippy::erasing_op,
        clippy::cast_possible_truncation,
        clippy::cast_precision_loss,
        clippy::cast_ptr_alignment,
        clippy::cast_possible_wrap,
        clippy::needless_range_loop,
        clippy::similar_names
    )]
    pub fn activate_ft_and_propagate_l1(
        stm_psqt: &Align<[i16; L1_SIZE]>,
        ntm_psqt: &Align<[i16; L1_SIZE]>,
        stm_thrt: &Align<[i16; L1_SIZE]>,
        ntm_thrt: &Align<[i16; L1_SIZE]>,
        weights: &Align<[i8; L1_SIZE * L2_SIZE]>,
        biases: &Align<[f32; L2_SIZE]>,
        output: &mut Align<[f32; L2_SIZE]>,
    ) {
        const L1_PAIR_COUNT: usize = L1_SIZE / 2;
        const NNZ_INPUT_SIMD_WIDTH: usize =
            std::mem::size_of::<VecI32>() / std::mem::size_of::<i32>();
        const NNZ_CHUNK: usize = max!(NNZ_INPUT_SIMD_WIDTH * 2, 8);
        const NNZ_OUTPUTS_PER_CHUNK: usize = NNZ_CHUNK / 8;

        // on NEON, the instruction used for mulhi doubles the results.
        // this is effectively a shift by another bit, so we shift by one fewer.
        const SHIFT: S = 16 - FT_SHIFT as S - cfg!(target_feature = "neon") as S;

        // SAFETY: Breaking it down by unsafe operations:
        // 1. get_unchecked[_mut] / .as[_mut]_ptr().add(): We only ever index at most
        // div_ceil(L1_PAIR_COUNT - 1, I16_CHUNK * 2) + I16_CHUNK + L1_PAIR_COUNT
        // into the `acc` array. This is in bounds, as `acc` has length L1_PAIR_COUNT * 2.
        // Additionally, we only ever index at most div_ceil(L1_PAIR_COUNT - 1, I16_CHUNK * 2) + L1_PAIR_COUNT
        // into the `ft_outputs` array. This is in bounds, as `ft_outputs` has length L1_PAIR_COUNT * 2.
        // 2. SIMD instructions: All of our loads and stores are aligned.
        // 3. Use of MaybeUninit: We always store into the entirety of `ft_outputs`, before
        // reading from it. Additionally, find_nnz returns a slice into `nnz` that it has
        // initialised, so we can soundly read from it.
        unsafe {
            let ft_zero = simd::zero_i16();
            let ft_one = simd::splat_i16(QA);

            let mut ft_outputs: Align<[MaybeUninit<u8>; L1_SIZE]> =
                MaybeUninit::uninit().assume_init();
            let mut nnz: Align<[MaybeUninit<u16>; L1_SIZE / L1_CHUNK_PER_32]> =
                MaybeUninit::uninit().assume_init();
            let mut nnz_count = 0;

            let mut base = simd::v128_zero();
            let increment = simd::v128_splat(8);

            let mut offset = 0;
            for [psqt, thrt] in [[stm_psqt, stm_thrt], [ntm_psqt, ntm_thrt]] {
                // separate accumulators are maintained for the two input feature-sets, as
                // threat inputs are un-bucketed and can be more reliably updated without
                // refreshes. the PSQT accumulator additionally stores the biases,
                // the threat accumulator stores only the sum of threat matrix rows.
                let psqt_ptr = psqt.as_ptr();
                let thrt_ptr = thrt.as_ptr();

                for i in (0..L1_PAIR_COUNT).step_by(I16_CHUNK * 2) {
                    // load the left-hand pair inputs
                    let input0ap = simd::load_i16(psqt_ptr.add(i + 0 * I16_CHUNK));
                    let input0bp = simd::load_i16(psqt_ptr.add(i + 1 * I16_CHUNK));
                    let input0at = simd::load_i16(thrt_ptr.add(i + 0 * I16_CHUNK));
                    let input0bt = simd::load_i16(thrt_ptr.add(i + 1 * I16_CHUNK));

                    // combine PSQT and threat preäctivations
                    let input0a = simd::add_i16(input0ap, input0at);
                    let input0b = simd::add_i16(input0bp, input0bt);

                    // load the right-hand pair inputs
                    let j = i + L1_PAIR_COUNT;
                    let input1ap = simd::load_i16(psqt_ptr.add(j + 0 * I16_CHUNK));
                    let input1bp = simd::load_i16(psqt_ptr.add(j + 1 * I16_CHUNK));
                    let input1at = simd::load_i16(thrt_ptr.add(j + 0 * I16_CHUNK));
                    let input1bt = simd::load_i16(thrt_ptr.add(j + 1 * I16_CHUNK));

                    // combine PSQT and threat preäctivations
                    let input1a = simd::add_i16(input1ap, input1at);
                    let input1b = simd::add_i16(input1bp, input1bt);

                    // crelu the left-hand inputs
                    let clipped0a = simd::min_i16(simd::max_i16(input0a, ft_zero), ft_one);
                    let clipped0b = simd::min_i16(simd::max_i16(input0b, ft_zero), ft_one);

                    // clip the right-hand inputs from above
                    let clipped1a = simd::min_i16(input1a, ft_one);
                    let clipped1b = simd::min_i16(input1b, ft_one);

                    // shift and mulhi such that the high bits we get are equal to crelu(x₁) × crelu(x₂)
                    let producta = simd::shift_mul_high_i16::<SHIFT>(clipped0a, clipped1a);
                    let productb = simd::shift_mul_high_i16::<SHIFT>(clipped0b, clipped1b);

                    // pack the resulting values in to u8s
                    let product_one = simd::pack_i16_to_u8(producta, productb);

                    // store to the ft output buffer
                    simd::store_u8(ft_outputs.as_mut_ptr().add(offset + i).cast(), product_one);
                }
                offset += L1_PAIR_COUNT;
            }

            // determine which parts of the result are nonzero, s.t. L1 forward can be sparse.
            for i in (0..L1_SIZE).step_by(U8_CHUNK * 2) {
                // load from the output of L0
                let product_one = simd::load_u8(ft_outputs.as_ptr().add(i).cast());
                let product_two = simd::load_u8(ft_outputs.as_ptr().add(i + U8_CHUNK).cast());

                // compute a bitmask, grouping in blocks of 4.
                // this means that a set of activations that looks like
                //     [ 0, 11,  0,  0,  0,  0, 17,  0] will not benefit from sparsity,
                // but [ 0,  0,  0,  0,  0, 11, 17,  0] will, as the first four are 0.
                let mut nnz_mask = 0;
                nnz_mask |= u32::from(simd::nonzero_mask_i32(simd::trans_i8_i32(product_one)));
                nnz_mask |= u32::from(simd::nonzero_mask_i32(simd::trans_i8_i32(product_two)))
                    << NNZ_INPUT_SIMD_WIDTH;

                // store the non-zero indices into the nnz buffer
                for j in 0..NNZ_OUTPUTS_PER_CHUNK {
                    let lookup = (nnz_mask >> (j * 8)) & 0xFF;
                    let entry = NNZ_TABLE.table.as_ptr().add(lookup as usize);
                    let offsets = simd::v128_load(entry.cast());
                    simd::v128_store(
                        nnz.as_mut_ptr().add(nnz_count).cast(),
                        simd::v128_add(base, offsets),
                    );
                    nnz_count += u32::count_ones(lookup) as usize;
                    base = simd::v128_add(base, increment);
                }
            }

            let nnz_slice = std::slice::from_raw_parts(nnz.as_ptr().cast::<u16>(), nnz_count);

            // logging for permutation
            #[cfg(feature = "nnz-counts")]
            for (i, elem) in ft_outputs.iter().enumerate() {
                let elem = elem.assume_init();
                let nnz = elem != 0;
                if nnz {
                    for (j, elem) in ft_outputs.iter().enumerate() {
                        let elem = elem.assume_init();
                        let nnz = elem != 0;
                        if nnz {
                            super::NNZ_COUNTS[i % L1_SIZE / 2][j % L1_SIZE / 2]
                                .fetch_add(1, std::sync::atomic::Ordering::Relaxed);
                        }
                    }
                }
            }

            #[cfg(feature = "ft-record")]
            {
                use std::io::Write;

                let ptr = std::ptr::from_ref(&ft_outputs);
                let ft_outputs = &*ptr.cast::<[u8; L1_SIZE]>();

                super::FT_OUTPUT_FILE
                    .lock()
                    .unwrap()
                    .write_all(ft_outputs)
                    .unwrap();
            }

            propagate_l1(&ft_outputs, nnz_slice, weights, biases, output);
        }
    }

    #[allow(clippy::similar_names, clippy::identity_op)]
    fn propagate_l1(
        ft_outputs: &Align<[MaybeUninit<u8>; L1_SIZE]>,
        nnz_slice: &[u16],
        weights: &Align<[i8; L1_SIZE * L2_SIZE]>,
        biases: &Align<[f32; L2_SIZE]>,
        output: &mut Align<[f32; L2_SIZE]>,
    ) {
        const NUM_ACCS: usize = L2_SIZE / F32_CHUNK;
        // SAFETY: Breaking it down by unsafe operations:
        // 1. get_unchecked[_mut] / .as[_mut]_ptr().add(): We only ever index at most
        // div_ceil(L1_PAIR_COUNT - 1, I16_CHUNK * 2) + I16_CHUNK + L1_PAIR_COUNT
        // into the `acc` array. This is in bounds, as `acc` has length L1_PAIR_COUNT * 2.
        // Additionally, we only ever index at most div_ceil(L1_PAIR_COUNT - 1, I16_CHUNK * 2) + L1_PAIR_COUNT
        // into the `ft_outputs` array. This is in bounds, as `ft_outputs` has length L1_PAIR_COUNT * 2.
        // 2. SIMD instructions: All of our loads and stores are aligned.
        unsafe {
            // &Align64<[MaybeUninit<u8>; L1_SIZE]>) -> &Align64<[i32; L1_SIZE / 4]>
            let input32 = reinterpret_as_i32s(ft_outputs);

            // note to a future cosmonaut: the auxiliary accumulator helps
            // with the latency of the VNNI instructions we use, but slightly
            // harms performance on weaker architectures, which do not suffer
            // from the same issues. If you feel like conditionally compiling
            // this based on target CPU, past-cosmonaut would not object.
            // c.f. https://github.com/official-stockfish/Stockfish/pull/6336.
            let mut acc = Align([0; L2_SIZE]);
            let mut aux = Align([0; L2_SIZE]);

            let nnz_count = nnz_slice.len();

            #[cfg(feature = "nnz-counts")]
            {
                NNZ_COUNT.fetch_add(nnz_count, Ordering::Relaxed);
                // each active block is four activations, so we divide by 4.
                NNZ_DENOM.fetch_add(L1_SIZE / 4, Ordering::Relaxed);
            }

            let tail_start = nnz_count - (nnz_count % 4);

            // affine transform
            for i in (0..tail_start).step_by(4) {
                // load the block indices from the sparse index list
                let nnz_ia = *nnz_slice.get_unchecked(i + 0) as usize;
                let nnz_ib = *nnz_slice.get_unchecked(i + 1) as usize;
                let nnz_ic = *nnz_slice.get_unchecked(i + 2) as usize;
                let nnz_id = *nnz_slice.get_unchecked(i + 3) as usize;
                // load the non-zero blocks, and splat them into SIMD registers.
                let input32_a = simd::trans_i32_i8(simd::splat_i32(*input32.get_unchecked(nnz_ia)));
                let input32_b = simd::trans_i32_i8(simd::splat_i32(*input32.get_unchecked(nnz_ib)));
                let input32_c = simd::trans_i32_i8(simd::splat_i32(*input32.get_unchecked(nnz_ic)));
                let input32_d = simd::trans_i32_i8(simd::splat_i32(*input32.get_unchecked(nnz_id)));
                // compute the block indices into the weights matrix.
                let w_offset_a = nnz_ia * L2_SIZE * L1_CHUNK_PER_32;
                let w_offset_b = nnz_ib * L2_SIZE * L1_CHUNK_PER_32;
                let w_offset_c = nnz_ic * L2_SIZE * L1_CHUNK_PER_32;
                let w_offset_d = nnz_id * L2_SIZE * L1_CHUNK_PER_32;
                // for each SIMD-block in the row, compute the product
                // of the non-zero activation with the corresponding
                // weight, and add it to the accumulator.
                for k in 0..NUM_ACCS {
                    let sum1 = simd::load_i32(acc.as_ptr().add(k * F32_CHUNK));
                    let sum2 = simd::load_i32(aux.as_ptr().add(k * F32_CHUNK));
                    let w_a = simd::load_i8(weights.as_ptr().add(w_offset_a + k * U8_CHUNK));
                    let w_b = simd::load_i8(weights.as_ptr().add(w_offset_b + k * U8_CHUNK));
                    let w_c = simd::load_i8(weights.as_ptr().add(w_offset_c + k * U8_CHUNK));
                    let w_d = simd::load_i8(weights.as_ptr().add(w_offset_d + k * U8_CHUNK));
                    let res1 = simd::madd_2xu8_to_i32(sum1, input32_a, w_a, input32_b, w_b);
                    let res2 = simd::madd_2xu8_to_i32(sum2, input32_c, w_c, input32_d, w_d);
                    simd::store_i32(acc.as_mut_ptr().add(k * F32_CHUNK), res1);
                    simd::store_i32(aux.as_mut_ptr().add(k * F32_CHUNK), res2);
                }
            }

            // process the tail
            for i in tail_start..nnz_count {
                // load the block index from the sparse index list
                let nnz_i = *nnz_slice.get_unchecked(i) as usize;
                // load the non-zero block, and splat it into a SIMD register.
                let input32 = simd::trans_i32_i8(simd::splat_i32(*input32.get_unchecked(nnz_i)));
                // compute the block index into the weights matrix.
                let w_offset = nnz_i * L2_SIZE * L1_CHUNK_PER_32;
                // for each SIMD-block in the row, compute the product
                // of the non-zero activation with the corresponding
                // weight, and add it to the accumulator.
                for k in 0..NUM_ACCS {
                    let sum = simd::load_i32(acc.as_ptr().add(k * F32_CHUNK));
                    let weight = simd::load_i8(weights.as_ptr().add(w_offset + k * U8_CHUNK));
                    let res = simd::madd_u8_to_i32(sum, input32, weight);
                    simd::store_i32(acc.as_mut_ptr().add(k * F32_CHUNK), res);
                }
            }

            // fold in the aux accumulators
            for k in 0..NUM_ACCS {
                let sum1 = simd::load_i32(acc.as_ptr().add(k * F32_CHUNK));
                let sum2 = simd::load_i32(aux.as_ptr().add(k * F32_CHUNK));
                let res = simd::add_i32(sum1, sum2);
                simd::store_i32(acc.as_mut_ptr().add(k * F32_CHUNK), res);
            }

            // Hard-Swish activation
            // act(x) = x · clamp(x + k/2, 0, k) / k
            let zero = simd::zero_f32();
            let k = simd::splat_f32(SWISH_K);
            let inv_k = simd::splat_f32(1.0 / SWISH_K);
            let half_k = simd::splat_f32(SWISH_K / 2.0);
            let sum_mul = simd::splat_f32(L1_MUL);
            for i in 0..L2_SIZE / F32_CHUNK {
                // convert i32 to f32, multiplying by the quantisation constant
                let bias = simd::load_f32(biases.as_ptr().add(i * F32_CHUNK));
                let unscaled = simd::i32_to_f32(simd::load_i32(acc.as_ptr().add(i * F32_CHUNK)));
                let preact = simd::madd_f32(unscaled, sum_mul, bias);
                // activate
                let gate = simd::min_f32(simd::max_f32(simd::add_f32(preact, half_k), zero), k);
                let act = simd::mul_f32(preact, gate);
                let act = simd::mul_f32(act, inv_k);
                simd::store_f32(output.as_mut_ptr().add(i * F32_CHUNK), act);
            }
        }
    }

    #[allow(clippy::needless_range_loop, clippy::cast_ptr_alignment)]
    pub fn propagate_l2(
        inputs: &Align<[f32; L2_SIZE]>,
        weights: &Align<[f32; L2_SIZE * L3_SIZE * 2]>,
        biases: &Align<[f32; L3_SIZE * 2]>,
        output: &mut Align<[f32; L3_SIZE]>,
    ) {
        // skip connection safety:
        const { assert!(L2_SIZE == L3_SIZE) };
        // SAFETY: Breaking it down by unsafe operations:
        // 1. get_unchecked[_mut] / .as[_mut]_ptr().add(): We only ever index at most (L3_SIZE * 2 / F32_CHUNK - 1) * F32_CHUNK
        // into the `sums` and `biases` arrays. This is in bounds, as `sums` has length L3_SIZE * 2 and
        // `biases` has length L3_SIZE * 2. We only ever index at most
        // (L2_SIZE - 1) * L3_SIZE * 2 + (L3_SIZE * 2 / F32_CHUNK - 1) * F32_CHUNK
        // into the `weights` array. This is in bounds, as `weights` has length L2_SIZE * L3_SIZE * 2.
        // We only ever index at most L2_SIZE - 1 into the `inputs` array. This is in bounds, as `inputs`
        // has length L2_SIZE. In the activation loop, we index at most (L3_SIZE / F32_CHUNK - 1) * F32_CHUNK + L3_SIZE
        // into `sums`, which is in bounds as `sums` has length L3_SIZE * 2.
        // 2. SIMD instructions: All of our loads and stores are aligned.
        unsafe {
            let mut sums = biases.clone();

            // affine transform
            for i in 0..L2_SIZE {
                let activation = simd::splat_f32(*inputs.get_unchecked(i));
                for j in 0..L3_SIZE * 2 / F32_CHUNK {
                    let acc = simd::load_f32(sums.as_ptr().add(j * F32_CHUNK));
                    let weight =
                        simd::load_f32(weights.as_ptr().add(i * L3_SIZE * 2 + j * F32_CHUNK));
                    let res = simd::madd_f32(activation, weight, acc);
                    simd::store_f32(sums.as_mut_ptr().add(j * F32_CHUNK), res);
                }
            }

            // SwiGLU activation
            // act(x) = HardSwish6(x1) * x2
            let zero = simd::zero_f32();
            let k = simd::splat_f32(SWISH_K);
            let inv_k = simd::splat_f32(1.0 / SWISH_K);
            let half_k = simd::splat_f32(SWISH_K / 2.0);
            for i in 0..L3_SIZE / F32_CHUNK {
                let gate_preact = simd::load_f32(sums.as_ptr().add(i * F32_CHUNK));
                let id_preact = simd::load_f32(sums.as_ptr().add(i * F32_CHUNK + L3_SIZE));
                let clamped =
                    simd::min_f32(simd::max_f32(simd::add_f32(gate_preact, half_k), zero), k);
                let swish = simd::mul_f32(simd::mul_f32(gate_preact, clamped), inv_k);
                let act = simd::mul_f32(swish, id_preact);
                // skip connection
                let input = simd::load_f32(inputs.as_ptr().add(i * F32_CHUNK));
                let act = simd::add_f32(act, input);
                simd::store_f32(output.as_mut_ptr().add(i * F32_CHUNK), act);
            }
        }
    }

    #[allow(clippy::modulo_one)]
    pub fn propagate_l3(
        inputs: &Align<[f32; L3_SIZE]>,
        weights: &Align<[f32; L3_SIZE]>,
        bias: f32,
        output: &mut f32,
    ) {
        // These weird multiple-sum shenanigans is to make sure we add the floats in the exact same manner
        // and order on ALL architectures, so that behaviour is deterministic
        // We multiply the weights by the inputs, and sum them up
        const NUM_SUMS: usize = AVX512CHUNK / F32_CHUNK;
        // SAFETY: Breaking it down by unsafe operations:
        // 1. get_unchecked[_mut] / .as[_mut]_ptr().add(): We only ever index at most (L3_SIZE / F32_CHUNK - 1) * F32_CHUNK
        // into the `weights` and `inputs` arrays. This is in bounds, as `weights` has length L3_SIZE and
        // `inputs` has length L3_SIZE.
        // 2. SIMD instructions: All of our loads and stores are aligned.
        unsafe {
            let mut sum_vecs = [simd::zero_f32(); NUM_SUMS];

            // affine transform
            for i in 0..L3_SIZE / F32_CHUNK {
                let act = simd::load_f32(inputs.as_ptr().add(i * F32_CHUNK));
                let weight = simd::load_f32(weights.as_ptr().add(i * F32_CHUNK));
                sum_vecs[i % NUM_SUMS] = simd::madd_f32(act, weight, sum_vecs[i % NUM_SUMS]);
            }

            *output = simd::reduce_add_f32s(&sum_vecs) + bias;
        }
    }
}

pub use simd::*;

use super::{QA, QB};

// logging for permutation
#[cfg(feature = "nnz-counts")]
pub static NNZ_COUNTS: [[std::sync::atomic::AtomicU64; super::L1_SIZE / 2]; super::L1_SIZE / 2] = const {
    // Safety: AtomicU64 is repr-compatible with u64.
    unsafe { std::mem::transmute([[0u64; super::L1_SIZE / 2]; super::L1_SIZE / 2]) }
};
