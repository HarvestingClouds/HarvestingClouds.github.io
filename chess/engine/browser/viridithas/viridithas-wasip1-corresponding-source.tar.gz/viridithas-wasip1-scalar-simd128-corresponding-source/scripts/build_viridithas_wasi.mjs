#!/usr/bin/env node
import { spawnSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const engineDir = process.env.VIRIDITHAS_BUILD_DIR ?? path.join(root, '.local_engines', 'viridithas-wasi-src');
const netDir = process.env.VIRIDITHAS_NET_DIR ?? path.join(root, '.local_engines', 'viridithas-nets');
const out = process.env.VIRIDITHAS_WASM_OUT ?? path.join(root, 'public', 'viridithas', 'viridithas.wasm');
const repo = process.env.VIRIDITHAS_REPO ?? 'https://github.com/cosmobobak/viridithas.git';
const ref = process.env.VIRIDITHAS_REF ?? '0631113e2215714c54d397cce9a8caebc5e6f8ee';
const netUrl = process.env.VIRIDITHAS_NET_URL ?? 'https://github.com/cosmobobak/viridithas-networks/releases/download/v109/sandhi-s2-b200.nnue.zst';
const netSha256 = process.env.VIRIDITHAS_NET_SHA256 ?? '066c172e22c25ee3d3b4084ad44ff761426f906a9c536cabd0127d17413d0585';
const netPath = path.join(netDir, path.basename(new URL(netUrl).pathname));
const patchPath = path.join(root, 'patches', 'viridithas-wasip1.patch');

function run(command, args, options = {}) {
  console.log(`$ ${command} ${args.join(' ')}`);
  const result = spawnSync(command, args, { stdio: 'inherit', ...options });
  if (result.status !== 0) process.exit(result.status ?? 1);
}

function canRun(command, args, options = {}) {
  const result = spawnSync(command, args, { stdio: 'ignore', ...options });
  return result.status === 0;
}

function sha256(file) {
  return createHash('sha256').update(fs.readFileSync(file)).digest('hex');
}

function applyPatchOnce() {
  if (canRun('git', ['apply', '--check', patchPath], { cwd: engineDir })) {
    run('git', ['apply', patchPath], { cwd: engineDir });
    return;
  }
  if (canRun('git', ['apply', '--reverse', '--check', patchPath], { cwd: engineDir })) {
    console.log(`Patch already applied: ${patchPath}`);
    return;
  }
  run('git', ['apply', patchPath], { cwd: engineDir });
}

fs.mkdirSync(path.dirname(engineDir), { recursive: true });
fs.mkdirSync(netDir, { recursive: true });
fs.mkdirSync(path.dirname(out), { recursive: true });

if (process.env.VIRIDITHAS_SKIP_GIT !== '1') {
  if (!fs.existsSync(path.join(engineDir, '.git'))) {
    run('git', ['init', engineDir]);
    run('git', ['remote', 'add', 'origin', repo], { cwd: engineDir });
  }
  // Fetch only the pinned MIT source; v21+ is outside our license boundary.
  run('git', ['fetch', '--depth=1', '--no-tags', 'origin', ref], { cwd: engineDir });
  run('git', ['checkout', ref], { cwd: engineDir });
  run('git', ['reset', '--hard'], { cwd: engineDir });
  run('git', ['clean', '-fdx', '-e', 'target'], { cwd: engineDir });
}

if (!fs.existsSync(netPath)) {
  run('curl', ['-L', '--fail', '-o', netPath, netUrl]);
}
const actualNetSha256 = sha256(netPath);
if (actualNetSha256 !== netSha256) {
  throw new Error(`Viridithas network checksum mismatch for ${netPath}: expected ${netSha256}, got ${actualNetSha256}`);
}
fs.copyFileSync(netPath, path.join(engineDir, 'viridithas.nnue.zst'));

applyPatchOnce();
run('rustup', ['target', 'add', 'wasm32-wasip1']);
const targetFeatures = [
  '+bulk-memory',
  ...(process.env.VIRIDITHAS_WASM_SIMD === '1' ? ['+simd128'] : []),
  ...(process.env.VIRIDITHAS_WASM_RELAXED_SIMD === '1' ? ['+simd128', '+relaxed-simd'] : []),
].join(',');
run('cargo', ['build', '--release', '--target', 'wasm32-wasip1', '--no-default-features'], {
  cwd: engineDir,
  env: { ...process.env, RUSTFLAGS: `${process.env.RUSTFLAGS ?? ''} -C target-feature=${targetFeatures}`.trim() },
});

const built = path.join(engineDir, 'target', 'wasm32-wasip1', 'release', 'viridithas.wasm');
fs.copyFileSync(built, out);
console.log(`Wrote ${out}`);
